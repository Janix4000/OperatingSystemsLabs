#include <stdio.h>
#include "lib_merge.h"

#include <stdlib.h>

int main()
{
    test_function();
    //printf("Hello World! Magic number is %d!\n", test_function());
    return 0;
}